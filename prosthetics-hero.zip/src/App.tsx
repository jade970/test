import React, { useState, useEffect } from 'react';
import { LogIn, UserPlus, Menu, X, Sun, Moon } from 'lucide-react';

const App: React.FC = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDayMode, setIsDayMode] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  const toggleTheme = () => {
    setIsTransitioning(true);
    setIsDayMode((prev) => !prev);
    // After the pull-down phase completes (300ms transition), let it rebound back with return-easing
    setTimeout(() => {
      setIsTransitioning(false);
    }, 320);
  };

  const navLinks = [
    { href: '#mission', label: 'Purpose' },
    { href: '#how', label: 'The Process' },
    { href: '#pricing', label: 'Tariffs' },
  ];

  return (
    <div className={`relative min-h-screen overflow-hidden font-sans transition-colors duration-1000 ${
      isDayMode ? 'bg-[#f7f7f5] text-zinc-900' : 'bg-black text-white'
    }`}>
      {/* Transitioning Background Elements Assembly */}
      <div className={`absolute inset-0 pointer-events-none select-none ${
        isTransitioning ? 'pull-down' : 'bg-front'
      }`}>
        {/* Night Background Video */}
         <video
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
            isDayMode ? 'opacity-0' : 'opacity-60'
          }`}
          src="https://d8j0ntlcm91z4.cloudfront.net/user_3AOg24a70rmZTeZNMTlapbCVbca/hf_20260527_165058_fbdf1f94-43eb-4fcc-b3f6-99c65ab6050c.mp4"
          autoPlay
          muted
          loop
          playsInline
        />

        {/* Day Background Video */}
        <video
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
            isDayMode ? 'opacity-70' : 'opacity-0'
          }`}
          src="https://d8j0ntlcm91z4.cloudfront.net/user_3AOg24a70rmZTeZNMTlapbCVbca/hf_20260527_164534_71c75b68-aa50-4d09-9a11-0b8230357d46.mp4"
          autoPlay
          muted
          loop
          playsInline
        />
      </div>

      {/* Uniform Liquid Glass Backdrop Layer Over Background Videos */}
      <div className={`absolute inset-0 pointer-events-none transition-all duration-1000 z-1 ${
        isDayMode 
          ? 'bg-white/25' 
          : 'bg-zinc-950/25'
      }`} />

      {/* Responsive Navbar */}
      <nav className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-4 sm:px-6 md:px-10 py-4 sm:py-6">
        {/* Logo */}
        <div className={`flex items-center gap-2 transition-colors duration-500 ${
          isDayMode ? 'text-zinc-950' : 'text-white'
        }`}>
          <span className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight">
            LinkFlow<sup className="text-[10px] sm:text-xs font-semibold">TM</sup>
          </span>
        </div>

        {/* Desktop pill nav */}
        <div className={`hidden lg:flex items-center gap-1 backdrop-blur-md rounded-full pl-6 pr-1 py-1 shadow-lg border transition-all duration-500 ${
          isDayMode 
            ? 'bg-white/70 border-zinc-200/50 shadow-black/5' 
            : 'bg-zinc-900/80 border-zinc-800/80 shadow-black/30'
        }`}>
          {navLinks.map((link, i) => (
            <a
              key={link.href}
              href={link.href}
              className={`text-sm px-3 py-2 transition-colors duration-300 ${
                isDayMode 
                  ? i === 0 ? 'font-semibold text-zinc-950' : 'font-medium text-zinc-600 hover:text-zinc-950'
                  : i === 0 ? 'font-semibold text-white' : 'font-medium text-zinc-400 hover:text-white'
              }`}
            >
              {link.label}
            </a>
          ))}
          <button className={`ml-2 text-sm font-medium px-5 py-2.5 rounded-full transition-colors cursor-pointer ${
            isDayMode 
              ? 'bg-zinc-950 hover:bg-zinc-800 text-white' 
              : 'bg-white hover:bg-zinc-200 text-zinc-950'
          }`}>
            Try it Live
          </button>
        </div>

        {/* Right side: custom slider toggle + auth links + hamburger */}
        <div className="flex items-center gap-3 sm:gap-6 font-sans">
          
          {/* Inspiration-based Day and Night sliding toggle button */}
          <div 
            onClick={toggleTheme}
            className={`relative flex items-center justify-between w-[114px] h-[40px] rounded-full p-1 cursor-pointer select-none transition-all duration-500 overflow-hidden border ${
              isDayMode 
                ? 'bg-zinc-200/55 hover:bg-zinc-200/75 border-zinc-300/60 shadow-[inset_0_2px_4px_rgba(0,0,0,0.06)] shadow-black/5' 
                : 'bg-zinc-900/70 hover:bg-zinc-900/90 border-zinc-800/80 shadow-inner'
            }`}
            style={{ backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)' }}
          >
            {/* Sliding crescent/rounded glass bulb thumb */}
            <div 
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-500 ease-[cubic-bezier(0.25,0.8,0.25,1)] border ${
                isDayMode 
                  ? 'translate-x-0 bg-white border-zinc-200 shadow-[0_3px_8px_rgba(0,0,0,0.12)]' 
                  : 'translate-x-[72px] bg-zinc-800/90 border-zinc-700/80 shadow-[0_3px_8px_rgba(0,0,0,0.4)]'
              }`}
            >
              {isDayMode ? (
                <Sun className="w-4 h-4 text-amber-500 fill-amber-400/20" />
              ) : (
                <Moon className="w-4 h-4 text-sky-400 fill-sky-400/20 animate-pulse" />
              )}
            </div>

            {/* Fading text labels inspired by the Light toggle design */}
            <span 
              className={`absolute right-4 text-xs font-semibold tracking-wide transition-all duration-500 ${
                isDayMode 
                  ? 'opacity-100 translate-x-0 text-zinc-800' 
                  : 'opacity-0 translate-x-4 pointer-events-none'
              }`}
            >
              Light
            </span>
            <span 
              className={`absolute left-4 text-xs font-semibold tracking-wide transition-all duration-500 ${
                !isDayMode 
                  ? 'opacity-100 translate-x-0 text-zinc-400' 
                  : 'opacity-0 -translate-x-4 pointer-events-none'
              }`}
            >
              Dark
            </span>
          </div>

          <a 
            href="#signup" 
            className={`hidden sm:flex items-center gap-2 text-sm font-medium transition-colors duration-300 ${
              isDayMode ? 'text-zinc-600 hover:text-zinc-950' : 'text-zinc-300 hover:text-white'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            Sign Me Up!
          </a>
          <a 
            href="#login" 
            className={`hidden sm:flex items-center gap-2 text-sm font-medium transition-colors duration-300 ${
              isDayMode ? 'text-zinc-600 hover:text-zinc-950' : 'text-zinc-300 hover:text-white'
            }`}
          >
            <LogIn className="w-4 h-4" />
            Enter
          </a>
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className={`lg:hidden relative flex items-center justify-center w-10 h-10 rounded-full border backdrop-blur-md transition-all duration-300 cursor-pointer ${
              isDayMode 
                ? 'bg-white/80 text-zinc-950 border-zinc-200/85 hover:bg-white' 
                : 'bg-zinc-900/85 text-white border-zinc-800/80 hover:bg-zinc-800'
            }`}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
          >
            <Menu
              className={`w-5 h-5 absolute transition-all duration-300 ${
                menuOpen ? 'opacity-0 rotate-90 scale-50' : 'opacity-100 rotate-0 scale-100'
              }`}
            />
            <X
              className={`w-5 h-5 absolute transition-all duration-300 ${
                menuOpen ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-50'
              }`}
            />
          </button>
        </div>
      </nav>

      {/* Mobile menu overlay */}
      <div
        className={`lg:hidden fixed inset-0 z-20 transition-opacity duration-300 ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setMenuOpen(false)}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      </div>

      {/* Mobile menu drawer */}
      <div
        className={`lg:hidden fixed top-0 right-0 bottom-0 z-20 w-[85%] max-w-sm shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
          isDayMode 
            ? 'bg-[#f7f7f5]/95 border-l border-zinc-200/80' 
            : 'bg-zinc-950/95 border-l border-zinc-900/80'
        } ${
          menuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{ backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}
      >
        <div className="flex flex-col h-full pt-21 px-8 pb-8">
          {/* Include responsive Day/Night switch right in mobile drawer as well for incredible accessibility */}
          <div className="mb-6 flex items-center justify-between border-b pb-4 border-zinc-200/20">
            <span className={`text-sm font-medium ${isDayMode ? 'text-zinc-600' : 'text-zinc-400'}`}>
              Theme
            </span>
            <div 
              onClick={toggleTheme}
              className={`relative flex items-center justify-between w-[114px] h-[40px] rounded-full p-1 cursor-pointer select-none transition-all duration-500 overflow-hidden border ${
                isDayMode 
                  ? 'bg-zinc-200/55 border-zinc-300/40' 
                  : 'bg-zinc-900/70 border-zinc-800'
              }`}
            >
              <div 
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-500 border ${
                  isDayMode 
                    ? 'translate-x-0 bg-white border-zinc-200 shadow' 
                    : 'translate-x-[72px] bg-zinc-800 border-zinc-700 shadow'
                }`}
              >
                {isDayMode ? (
                  <Sun className="w-4 h-4 text-amber-500" />
                ) : (
                  <Moon className="w-4 h-4 text-sky-450" />
                )}
              </div>
              <span className={`absolute right-4 text-xs font-semibold ${isDayMode ? 'opacity-100 text-zinc-800' : 'opacity-0'}`}>
                Light
              </span>
              <span className={`absolute left-4 text-xs font-semibold ${!isDayMode ? 'opacity-100 text-zinc-400' : 'opacity-0'}`}>
                Dark
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-1">
            {navLinks.map((link, i) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className={`text-2xl font-semibold py-4 border-b transition-all duration-500 ${
                  isDayMode 
                    ? 'text-zinc-950 border-zinc-200/60' 
                    : 'text-white border-zinc-800/40'
                } ${
                  menuOpen ? 'translate-x-0 opacity-100' : 'translate-x-8 opacity-0'
                }`}
                style={{ transitionDelay: menuOpen ? `${150 + i * 70}ms` : '0ms' }}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div
            className={`mt-8 flex flex-col gap-4 transition-all duration-500 ${
              menuOpen ? 'translate-x-0 opacity-100' : 'translate-x-8 opacity-0'
            }`}
            style={{ transitionDelay: menuOpen ? '400ms' : '0ms' }}
          >
            <a 
              href="#signup" 
              className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                isDayMode ? 'text-zinc-700 hover:text-zinc-950' : 'text-zinc-400 hover:text-white'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              Sign Me Up!
            </a>
            <a 
              href="#login" 
              className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                isDayMode ? 'text-zinc-700 hover:text-zinc-950' : 'text-zinc-400 hover:text-white'
              }`}
            >
              <LogIn className="w-4 h-4" />
              Enter
            </a>
            <button className={`mt-2 text-sm font-semibold px-5 py-3 rounded-full transition-colors cursor-pointer ${
              isDayMode 
                ? 'bg-zinc-950 hover:bg-zinc-800 text-white shadow' 
                : 'bg-white hover:bg-zinc-200 text-zinc-950'
            }`}>
              Try it Live
            </button>
          </div>
        </div>
      </div>

      {/* Hero content wrapper */}
      <div className="relative z-10 flex flex-col min-h-screen justify-end">
        
        {/* Hero content aligned bottom-left */}
        <section className="px-6 pb-20 sm:px-12 sm:pb-24 md:px-20 lg:px-24 xl:px-28">
          <div className="max-w-2xl transition-all duration-1000 transform translate-y-0 opacity-100">
            <h1 className={`text-[1.85rem] sm:text-[2.25rem] leading-[1.1] font-medium tracking-tight mb-6 transition-colors duration-500 ${
              isDayMode ? 'text-zinc-950' : 'text-white'
            }`}>
              Simple, smart prosthetics made for people who keep fighting.
            </h1>
            
            <div className="flex items-center gap-4">
              {/* Immersive UI accent divider element */}
              <div className={`h-[1px] w-8 transition-colors duration-500 ${
                isDayMode ? 'bg-zinc-300' : 'bg-zinc-800'
              }`} />
              <p className={`text-[12px] sm:text-[14px] uppercase tracking-[0.2em] font-light transition-colors duration-500 ${
                isDayMode ? 'text-zinc-500' : 'text-zinc-400 hover:text-white'
              }`}>
                Reclaim your movement now.
              </p>
            </div>
          </div>
        </section>

        {/* Ambient indicator dots (bottom-right) */}
        <div className="absolute bottom-10 right-6 sm:right-12 md:right-20 lg:right-24 xl:right-28 flex gap-2 opacity-80 transition-opacity duration-1000">
          <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-500 ${
            isDayMode ? 'bg-zinc-300' : 'bg-zinc-800'
          }`} />
          <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-500 ${
            isDayMode ? 'bg-zinc-300' : 'bg-zinc-800'
          }`} />
          <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-500 ${
            isDayMode ? 'bg-zinc-950' : 'bg-white'
          }`} />
        </div>
      </div>
    </div>
  );
};

export default App;
